var express = require('express');
var bodyParser = require('body-parser');
var port=8081;//use another port 8081 for this exercise
var hostname="localhost";

var app = express();

var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use(urlencodedParser);//attach body-parser middleware
app.use(bodyParser.json());//parse json data

app.get('/api/user', function(req, res){
    res.type('json');
    res.status(200)
    res.send(`[{'Name:'Jon', 'Age':'20'}], {'Name':'Mary, 'Age':'23'}`)
})


app.post('/api/user', function(req, res){
    var email = req.body.email;
    var name = req.body.name;
    var role = req.body.role;
    var password = req.body.password;

    res.type = 'html';
    res.status(200);
    html+='<html><body>'
})

app.delete('/user/:id', function(req, res){
    var id = req.params.id;
    res.type('json')
    res.status(200)
    res.send('User with ID ' + id + ' has been successfully deleted!')
})

app.put('/user/:id', function(req, res){
    var id = req.params.id;
    res.type('json')
    res.status(200)
    res.send('User with ID ' + id + ' has been successfully deleted!')
})


app.listen(port, hostname, () => {
    console.log(`Server started and accessible via http://${hostname}:${port}/`);
  });
