var express = require('express');
var serveStatic = require('serve-static');
var app = express();
var port = 3000;
var hostname = 'localhost';

app.use(function(req,res,next){
    var method = req.method;
    var url = req.url;
    var id = req.query.id;
    console.log(method);
    console.log(url);
    console.log(id);

    if(method=="POST"){
        res.type('html');
        res.send("<html><body>invalid request</body></html>");
    } else if (method == 'DELETE') {
        res.status(200)
        res.send('User with ID ' + id + ' has been successfully deleted!')
    } else if (method == 'PUT') {
        res.status(200)
        res.send('User with ID has been successfully updated with new email <email>!')
    } else {
        next()
    }

});

app.delete('/user/:id', function(req, res){
    var id = req.params.id;
    res.type('json')
    res.status(200)
    res.send('User with ID ' + id + ' has been successfully deleted!')
})

app.use(serveStatic(__dirname + "/public"));

app.listen(port,hostname,()=>{
    console.log(`Server started and accessible via http://${hostname}:${port}/`);
})

// var express = require('express');
// var serveStatic = require('serve-static');
// var app = express();
// var port = 3000;
// var hostname = 'localhost';

// app.use(function(req,res,next){
//     var method = req.method;
//     var url = req.url;
//     var id = req.query.id;
//     console.log(method);
//     console.log(url);
//     console.log(id);

//     if(method=="POST"){
//         res.type('html');
        
//         res.send("<html><body>invalid request</body></html>");
//     } else {
//         next();
//     }

// });

// app.use(serveStatic(__dirname + "/public"));

// app.listen(port,hostname,()=>{
//     console.log(`Server started and accessible via http://${hostname}:${port}/`);
// })