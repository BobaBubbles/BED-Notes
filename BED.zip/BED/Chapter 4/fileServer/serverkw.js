var express = require('express');
var bodyParser = require('body-parser');
var port=8081;  //use another port 8081 for this exercise
var hostname="localhost";

var app = express();

var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use(urlencodedParser);//attach body-parser middleware
app.use(bodyParser.json());//parse json data

// VERB + URL
app.get('/api/user', (req, res) => {
    res.status(200);
    res.type(".html");
    res.end("Data of all users sent!");

});

app.post("/api/user", (req, res) => {
    res.status(200);
    res.type(".html");
    res.send(`Received new user data:\nUsername: ${req.body.username}\nEmail: ${req.body.email}\nRole: ${req.body.role}\nPassword: ${req.body.password}`);
})

app.delete("/user/:id", (req, res) => {
    let uid = req.params.id;
    console.log(uid);
    res.status(200);
    res.send(JSON.stringify({"message": `User with ID ${uid} has been successfully deleted!`}));
})

app.put("/user/:id", (req, res) => {
    let uid = req.params.id;
    res.status(200);
    res.send(JSON.stringify({"message": `User with ID ${uid} has been successfully updated with new email ${req.body.email}!`}));
})

app.listen(port, hostname, () => {
    console.log(`Server started and accessible via http://${hostname}:${port}/`);
});
 
