const http = require('http');

var host = "localhost";
var port = 3000;

const server = http.createServer(function (req, res) {
    console.log(req.method);
    console.log(req.url);
    // console.log(req.id);

    res.end("<html><body>Hi, welcome to BED.</body></html>");
})

server.listen(port, host, function () {
    console.log(`Web Server hosted at http://${host}:${port}`)
})