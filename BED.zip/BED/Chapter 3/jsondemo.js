var stu = {"students":[
    {"name":"John","age":"18","course":"DIT"},
    {"name":"Mary","age":"18","course":"DISM"},
    {"name":"Jack","age":"28","course":"NSFSW"}
   ]
  };

var stuArray = stu.students;

for (let i = 0; i < stuArray.length; i++) {
    console.log(stuArray[i].name)
}

