x = (v1, v2) => v1*v2;

result = x(1,2);
console.log(result)