const fs = require('fs')

fs.readFile('fndemo.js', 'UTF8', function(err,data){

    if(err!=null){
        console.log(err);
    }else{
        console.log(data);
    }

});

console.log("@")
console.log('X')