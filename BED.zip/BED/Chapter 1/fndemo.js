function mul(num1, num2, num3) {
    result = num1 * num2 * num3
    return result;
}

console.log(mul(2,3,4))