var mul = function(num1, num2, num3){

    return (num1 * num2 * num3)

};

var mul2 = mul;

console.log(mul2(1,2,3))
console.log(mul(2,3,4))