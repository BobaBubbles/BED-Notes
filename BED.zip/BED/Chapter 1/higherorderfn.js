var printmsg = function(){
    for (let i = 0; i < 10; i++) {
        console.log('Hi');
    }    
}

setInterval(printmsg,2000) // Prints out the message every two seconds