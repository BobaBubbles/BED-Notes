var input = require('readline-sync');
var ans = []
var number = parseInt(input.question('Enter number here >> '))

function multiplicationTable(number) {
    for (let i = 1; i <= number; i++) {
        var pusharray = []
        for (let x = 1; x <= number; x++) {
            pusharray.push(i*x)
        };
        ans.push(pusharray)
    }
    return ans
};

console.log(multiplicationTable(number))