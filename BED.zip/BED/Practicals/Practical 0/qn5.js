var input = require('readline-sync');
var n = parseInt(input.question('Enter number here >> '))
var ans
var firstnum = 0
var secondnum = 1

function fin(n) {
    if (n == 0) {
        return 0
    } else {
        for (let i = 0; i < n; i++) {
            if (i % 2 == 0) {
                ans = firstnum + secondnum
                secondnum = ans
            } else {
                ans = firstnum + secondnum
                firstnum = ans
            };
        };
    }
    return ans
}

console.log(fin(n))