const numbers = [5, 1, 3, 5, 7, 12, 5, 72, 3]

function maxNumber(numbers) {
    var ans;
    if (numbers[0] <= numbers[1]) {
        ans = numbers[1]
    } else {
        ans = numbers[0]
    };
    for (let i = 2; i <= numbers.length; i++) {
        if (ans < numbers[i]) {
            ans = numbers[i];
        };
    };
    return ans
};

console.log(maxNumber(numbers))