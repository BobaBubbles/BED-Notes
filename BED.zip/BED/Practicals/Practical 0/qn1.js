var ans = [];
var big = 'Big';
var bus = 'Bus';
var bigbus = 'BigBus';
var input = require('readline-sync');

var n = parseInt(input.question('Enter your number here >> '));

function bigbus(n){
    for (let i = 1; i <= n; i++) {
        if (i % 15 == 0) {
            ans += bigbus + '\n'
        } else if (i % 3 == 0) {
            ans += big + '\n'
        } else if (i % 5 == 0) {
            ans += bus + '\n'
        } else {
            ans += i + '\n'
        };
    };
    return ans
};

console.log(bigbus(n))