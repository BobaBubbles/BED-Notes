const numbers = [1,2,3,4,5,6,7,8,9,10]

function calculateMean(numbers) {
    total = 0
    for (let i = 0; i < numbers.length; i++) {
        total += numbers[i]
    };
    ans = total / numbers.length
    return ans
}

console.log(calculateMean(numbers))