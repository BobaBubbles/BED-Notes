const mathlib = require('./mathslib.js');

console.log(mathlib.add(1,2))
console.log(mathlib.mul(4,5))
console.log(mathlib.div(10,5))