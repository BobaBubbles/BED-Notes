var add = function(num1, num2){
    return num1+num2;
}

var mul = function(num1, num2) {
    return num1*num2;
}

var div = function(num1, num2){
    return num1/num2;
}

module.exports.add = add;
module.exports.mul = mul;
module.exports.div = div;
