const app = require('./controller/app');

const host = 'localhost';
const port = 3001;

app.listen(port, host, function(){
    console.log(`Web server started at http://${host}:${port}`);
});