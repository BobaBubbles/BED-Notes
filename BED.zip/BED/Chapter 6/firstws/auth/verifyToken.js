var jwt = require('jsonwebtoken');
var config = require('../config');
const e = require('express');

var verifyFn = {
    verifyToken: function (req, res, next) {
        var token = req.headers['authorization'];

        res.type('json');
        if (!token || !token.includes('Bearer')) {
            res.status(403);
            res.send(`{"Message":"Not Authorized"}`);
        } else {
            // token = token.split('Bearer ')[1]; 
            token = token.substring(7);
            jwt.verify(token, config.JWTKey, function (err, decoded) {

                if (err) {
                    res.status(403);
                    res.send(`{"Message":"Not Authorized"}`);
                } else {
                    req.username = decoded.username;
                    req.role = decoded.role;
                    next();
                }
            });
        }
    },

    verifyAdminRights: function (req, res, next) {
        if (req.role == 'admin') {
            next();
        } else {
            res.status(403);
            res.send(`{"Message":"Not Authorized"}`);
        }
    }
}

module.exports = verifyFn;

