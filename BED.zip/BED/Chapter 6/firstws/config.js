var secret = "uyfgwiouhowhfew@#$#HU@23rfewfwe";

module.exports.JWTKey = secret;