const mysql = require('mysql')
const db = require('./databaseConfig')
var categoryDB = {

    getCategories: function (callback) {

        var dbConn = db.getConnection();

        dbConn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = 'select * from category'
                dbConn.query(sql, [], function (err, result) {
                    dbConn.end()
                    if (err) {
                        console.log(err)
                    } else (

                        console.log(result)
                    )
                    return callback(err, result);
                })
            }
        })

    }

}

module.exports = categoryDB;