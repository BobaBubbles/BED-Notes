var mysql = require('mysql');
var db = require('./databaseConfig');
var config = require('../config')
var jwt = require('jsonwebtoken');

var userDB = {

    //async function
    getUser: function (userid, callback) {
        var dbConn = db.getConnection();

        dbConn.connect(function (err) {

            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "select * from user where userid=?";
                dbConn.query(sql, [userid], function (err, result) {

                    dbConn.end();

                    if (err) {
                        console.log(err);

                    } else {
                        console.log(result);
                    }
                    return callback(err, result);
                });
            }
        });
    },

    getUsers: function (callback) {
        var dbConn = db.getConnection();

        dbConn.connect(function (err) {

            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "select * from user";
                dbConn.query(sql, [], function (err, result) {

                    dbConn.end();

                    if (err) {
                        console.log(err);

                    } else {
                        console.log(result);
                    }
                    return callback(err, result);
                });
            }
        });
    },

    insertUser: function (username, email, role, password, callback) {
        var dbConn = db.getConnection();

        dbConn.connect(function (err) {

            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "insert into user(username,email,role,password) Values(?,?,?,?)";

                dbConn.query(sql, [username, email, role, password], function (err, result) {

                    dbConn.end();

                    if (err) {
                        console.log(err);

                    } else {
                        console.log(result);
                    }
                    return callback(err, result);
                });
            }
        });
    },

    updateUser: function (email, password, username, callback) {
        var dbConn = db.getConnection();

        dbConn.connect(function (err) {

            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "update user set email=?,password=? where username=?";

                dbConn.query(sql, [email, password, username], function (err, result) {

                    dbConn.end();

                    if (err) {
                        console.log(err);

                    } else {
                        console.log(result);
                    }
                    return callback(err, result);
                });
            }
        });
    },

    deleteUser: function (userid, callback) {
        var dbConn = db.getConnection();

        dbConn.connect(function (err) {

            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "delete from user where userid =?";

                dbConn.query(sql, [userid], function (err, result) {

                    dbConn.end();

                    if (err) {
                        console.log(err);

                    } else {
                        console.log(result);
                    }
                    return callback(err, result);
                });
            }
        });
    },

    loginUser: function (email, password, callback) {
        var dbConn = db.getConnection();

        dbConn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {

                var sql = "select * from user where email = ? and password = ?";

                dbConn.query(sql, [email, password], function (err, result) {
                    if (err) {

                        console.log(err);
                        return callback(err, null);
                    } else {

                        if (result.length == 1) {//1 rec retrieved since email and password correct. Email is unique
                            //successful login
                            var role = result[0].role;
                            var username = result[0].username;
                            var token = jwt.sign({ "role": role, "username": username }, config.JWTKey, { expiresIn: 86400 });

                            return callback(null, token);

                        } else {
                            //login wrong...
                            return callback(null, null);

                        }
                    }
                });
            }
        });
    }
}

module.exports = userDB;
