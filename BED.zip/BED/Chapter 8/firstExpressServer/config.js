var secret='abc13nmmAXz'; //your own secret key
module.exports.key = secret;